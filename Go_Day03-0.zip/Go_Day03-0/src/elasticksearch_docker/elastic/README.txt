Скачайте с этого сайта версию 7.9.2
https://mirror.yandex.ru/mirrors/elastic/7/pool/main/e/elasticsearch/
и перенесите скаченный файл в эту папку
Поздравляю теперь вы можете запустить скрипт create_image.sh вы создадите образ для докера
После этого запустите run_container.sh
Молодец
Теперь ты можешь зайти на localhost:9200 и проверить запустился ли сервер elasticsearch)))))