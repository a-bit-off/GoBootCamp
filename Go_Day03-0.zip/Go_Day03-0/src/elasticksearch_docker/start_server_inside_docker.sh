#!/usr/bin/env sh

service elasticsearch start

while true
do
    echo "Press [CTRL+C] to exit this loop..."
    # Add more instructions here
    sleep 2
done


