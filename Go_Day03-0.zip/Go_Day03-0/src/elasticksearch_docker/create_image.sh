#!/usr/bin/env sh

docker build -t my_elastic:v1 .
