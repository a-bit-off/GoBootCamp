#!/usr/bin/env sh

docker run --name elas -p 9200:9200 -d my_elastic:v1